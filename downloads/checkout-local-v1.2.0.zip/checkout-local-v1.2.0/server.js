'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const zlib = require('node:zlib');
const ExcelJS = require('exceljs');

const ROOT = __dirname;
const PAGES = 'https://mylys.github.io';
const ENVS = ['production', 'sandbox'];
const { currencies: CURRENCIES, rows: DEFAULT_ROWS, validateSelection, compileRows } = require('./checkout-options');
const { identity, validateRows, makeActions } = require('./order-actions');
const profiles = require('./profile-config');
const { createMerchants, credentialVersion } = require('./merchant-config');
const MAX_UPLOAD = 1024 * 1024;
const MAX_UNCOMPRESSED = 10 * 1024 * 1024;
const TEST_ADDRESS_REGIONS = {
  MY: { state:'Kuala Lumpur', city:'Kuala Lumpur', postcode:'50000' },
  ID: { state:'DKI Jakarta', city:'Jakarta', postcode:'10110' },
  JP: { state:'Tokyo', city:'Shinjuku', postcode:'160-0022' },
  VN: { state:'Ho Chi Minh', city:'Ho Chi Minh', postcode:'70000' },
  TH: { state:'Bangkok', city:'Bangkok', postcode:'10110' },
  PH: { state:'Metro Manila', city:'Manila', postcode:'1000' },
  HK: { state:'Hong Kong, China', city:'Hong Kong, China', postcode:'000000' },
  CN: { state:'Guangdong', city:'Shenzhen', postcode:'518000' },
  KR: { state:'Seoul', city:'Gangnam-gu', postcode:'06236' },
  SG: { state:'Singapore', city:'Singapore', postcode:'018956' }
};
function publicIPv4(ip) {
  if (typeof ip !== 'string' || net.isIP(ip) !== 4) return false;
  const [a, b, c] = ip.split('.').map(Number);
  return !(a === 0 || a === 10 || a === 127 || a >= 224 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && (b === 168 || (b === 0 && (c === 0 || c === 2)))) || (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) || (a === 203 && b === 0 && c === 113));
}
function testAddress(country) {
  if (!Object.hasOwn(TEST_ADDRESS_REGIONS, country)) fail('不支持该国家或地区的测试地址');
  const number = crypto.randomInt(1, 10000);
  return { address:{ country, ...TEST_ADDRESS_REGIONS[country], street:country === 'CN' || country === 'HK' ? `沙箱测试路 ${number} 号（虚构）` : `${number} Sandbox Test Street (Synthetic)` }, synthetic:true, notice:'仅沙箱测试，非真实可投递地址' };
}
const ORDER_FIELDS = ['amount','currency','merchantTransactionId','productName','unitPrice','number','customerEmail','language','shopperIP','merchantUserId','captureDelayHours','payResultUrl','payCancelUrl','notificationUrl','tradeCountry','paymentMethods','shippingCountry','shippingState','shippingCity','shippingStreet','shippingPostcode','billingCountry','billingState','billingCity','billingStreet','billingPostcode'];
const TEXT_FIELDS = ['accId','clientId','salt','merchantTransactionId','merchantUserId','shippingPostcode','billingPostcode'];
const HISTORY_FIELDS = ['id','merchantTransactionId','env','amount','currency','mode','status','createdAt','updatedAt','transactionId','simulated','productionTestMode','syntheticProfile','syntheticAddress','notificationRequestId','notificationStatus','tradeCountry','merchantId','merchantFingerprint','notificationUrl','queriedAt','pendingAction','lastAction','lastActionId','lastActionStatus','refundAttempted','merchantRefundId','refundId','refundAmount','refundStatus','refundedAmount','refundQueriedAt','cancelStatus'];
function fail(message, status = 400) { const e = new Error(message); e.status = status; throw e; }
function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
function environment(env) { if (!ENVS.includes(env)) fail('环境必须为 production 或 sandbox'); return env; }
function endpoint(env) { environment(env); return env === 'sandbox' ? 'https://sandbox-acquirer-payment.pingpongx.com/v4/payment/prePay' : 'https://acquirer-payment.pingpongx.com/v4/payment/prePay'; }
function mask(value) { return !value ? '' : value.length <= 8 ? '••••' : `${value.slice(0, 4)}••••${value.slice(-4)}`; }
function signBody(body, salt) {
  if (!object(body) || typeof salt !== 'string' || !salt) fail('签名参数无效');
  const pairs = Object.keys(body).filter(k => k !== 'sign' && body[k] !== null && body[k] !== undefined).sort().flatMap(k => {
    if (typeof body[k] !== 'string') fail('签名字段必须为字符串');
    return body[k].trim() ? [`${k}=${body[k]}`] : [];
  });
  return crypto.createHash('sha256').update(salt + pairs.join('&'), 'utf8').digest('hex').toUpperCase();
}
function verifySign(body, salt) {
  try { if (!/^[a-f\d]{64}$/i.test(body?.sign || '')) return false; return crypto.timingSafeEqual(Buffer.from(body.sign.toUpperCase()), Buffer.from(signBody(body, salt))); } catch { return false; }
}
function atomicWrite(file, value) {
  const tmp = `${file}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  try { fs.writeFileSync(tmp, JSON.stringify(value, null, 2), { mode: 0o600, flag: 'wx' }); fs.chmodSync(tmp, 0o600); fs.renameSync(tmp, file); }
  finally { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); }
}
function readJson(file, fallback) { if (!fs.existsSync(file)) return fallback; return JSON.parse(fs.readFileSync(file, 'utf8')); }
function safeOrder(order) {
  const out = Object.fromEntries(HISTORY_FIELDS.filter(k => ['string','number','boolean'].includes(typeof order[k])).map(k => [k, order[k]]));
  for (const name of ['requestSummary', 'responseSummary']) if (object(order[name])) out[name] = Object.fromEntries(['merchantTransactionId','amount','currency','captureDelayHours','tradeCountry','code','signatureVerified'].filter(k => ['string','number','boolean'].includes(typeof order[name][k])).map(k => [k,order[name][k]]));
  if (Array.isArray(order.paymentMethods)) out.paymentMethods = order.paymentMethods.filter(x => typeof x === 'string');
  if (out.requestSummary && out.paymentMethods) out.requestSummary.paymentMethods = [...out.paymentMethods];
  return out;
}
function minor(value, currency, field) {
  const digits = currency === undefined ? 6 : CURRENCIES[currency];
  if (typeof value !== 'string' || value.length > 24 || !/^(0|[1-9]\d*)(\.\d+)?$/.test(value) || (value.split('.')[1] || '').length > digits) fail(`${field} 必须是有效的固定小数金额字符串（${currency === undefined ? '未指定币种' : currency} 最多 ${digits} 位小数）`);
  return BigInt(value.split('.')[0]) * 10n ** BigInt(digits) + BigInt((value.split('.')[1] || '').padEnd(digits, '0') || '0');
}
function checkUrl(value, field, env) {
  if (typeof value !== 'string') fail(`${field} URL 无效`);
  let u; try { u = new URL(value); } catch { fail(`${field} URL 无效`); }
  if (field === 'notificationUrl' && (u.search || u.hash || u.pathname === '/')) fail('notificationUrl 必须提供具体路径且不能包含 query 或 hash');
  const loopback = ['localhost','127.0.0.1','[::1]'].includes(u.hostname);
  if (u.username || u.password || (u.protocol !== 'https:' && !(env === 'sandbox' && field !== 'notificationUrl' && loopback && u.protocol === 'http:')) || (field === 'notificationUrl' && loopback)) fail(`${field} 必须使用 HTTPS 公网地址；仅沙箱回跳允许 localhost HTTP`);
}
function validateBiz(input, env, { real = true, rows = DEFAULT_ROWS } = {}) {
  environment(env); if (!object(input)) fail('bizContent 必须是对象');
  const b = JSON.parse(JSON.stringify(input));
  delete b.syntheticProfile; delete b.syntheticAddress; delete b.productionTestMode; delete b.productionConfirmed;
  for (const key of ['currency','tradeCountry','paymentMethods']) if (b[key] == null || (typeof b[key] === 'string' && !b[key].trim())) delete b[key];
  if (b.currency !== undefined && (typeof b.currency !== 'string' || !Object.hasOwn(CURRENCIES, b.currency))) fail('currency 不在支持的金额精度币种集合中');
  if (b.paymentMethods !== undefined) {
    if (!Array.isArray(b.paymentMethods) || b.paymentMethods.some(method => typeof method !== 'string')) fail('paymentMethods 必须是字符串数组');
    b.paymentMethods = [...new Set(b.paymentMethods)];
    if (!b.paymentMethods.length) delete b.paymentMethods;
  }
  const selectionError = validateSelection(b, rows); if (selectionError) fail(selectionError);
  if (typeof b.merchantTransactionId !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(b.merchantTransactionId)) fail('merchantTransactionId 必须为有效文本 ID');
  if (b.merchantUserId !== undefined && typeof b.merchantUserId !== 'string') fail('merchantUserId 必须为文本');
  const amount = minor(b.amount, b.currency, 'amount'); if (amount <= 0n) fail('订单金额必须大于 0');
  if (!Array.isArray(b.goods) || !b.goods.length || b.goods.length > 100) fail('需要 1 至 100 个商品项');
  let total = 0n;
  for (const g of b.goods) {
    if (!object(g) || typeof g.name !== 'string' || !g.name.trim()) fail('商品名称不能为空');
    if (real) {
      if (typeof g.imgUrl !== 'string' || !g.imgUrl.trim() || g.imgUrl.length > 255) fail('goods.imgUrl 必须提供不超过 255 字符的商品主图链接');
      let image; try { image = new URL(g.imgUrl); } catch { fail('goods.imgUrl 必须为有效的 HTTP(S) URL'); }
      if (!['http:', 'https:'].includes(image.protocol) || image.username || image.password) fail('goods.imgUrl 必须为无凭据的 HTTP(S) URL');
    }
    if (!['Y','N'].includes(g.virtualProduct)) fail('virtualProduct 必须为 Y 或 N');
    if (typeof g.number !== 'string' || !/^[1-9]\d{0,8}$/.test(g.number)) fail('商品数量必须为正整数字符串');
    const price = minor(g.unitPrice, b.currency, 'unitPrice'); if (price <= 0n) fail('商品单价必须大于 0'); total += price * BigInt(g.number);
  }
  if (total !== amount) fail('商品金额合计与订单金额不一致');
  if (real && (b.captureDelayHours == null || b.captureDelayHours === '')) fail('真实调用必须明确选择 captureDelayHours，不能留空');
  b.captureDelayHours = b.captureDelayHours === undefined || b.captureDelayHours === '' ? 0 : b.captureDelayHours;
  if (!Number.isInteger(b.captureDelayHours) || b.captureDelayHours < -1 || b.captureDelayHours > 168) fail('captureDelayHours 必须是 -1 至 168 的整数');
  for (const k of ['payResultUrl','payCancelUrl']) checkUrl(b[k], k, env);
  if (b.notificationUrl) checkUrl(b.notificationUrl, 'notificationUrl', env); else delete b.notificationUrl;
  if (typeof b.shopperIP !== 'string' || !net.isIP(b.shopperIP)) fail('shopperIP 必须是有效 IP 地址');
  if (real && (b.shopperIP === '::1' || b.shopperIP === '::' || /^(127\.|10\.|192\.168\.|169\.254\.|0\.|172\.(1[6-9]|2\d|3[01])\.)/.test(b.shopperIP) || /^(fc|fd|fe80|::ffff:)/i.test(b.shopperIP))) fail('真实调用请填写买家的真实公网 shopperIP，不能使用回环或内网 IP');
  const physical = b.goods.some(g => g.virtualProduct === 'N');
  const emailValid = object(b.customer) && typeof b.customer.email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.customer.email);
  if (physical && !emailValid) fail('实物订单必须提供 customer.email');
  if (!physical && !emailValid && !(typeof b.merchantUserId === 'string' && b.merchantUserId.trim())) fail('虚拟订单必须提供有效 customer.email 或 merchantUserId');
  for (const name of physical ? ['shippingAddress','billingAddress'] : ['billingAddress']) {
    if (!object(b[name])) fail(`订单必须提供 ${name}（其他虚拟类仍需账单地址）`);
    for (const field of ['country','state','city','street','postcode']) if (typeof b[name][field] !== 'string' || !b[name][field].trim()) fail(`订单必须提供 ${name}.${field}`);
  }
  return b;
}
function checkZip(buffer) {
  if (!buffer.length || buffer.length > MAX_UPLOAD) fail('xlsx 压缩大小必须小于等于 1MB');
  let end = -1; for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 65557); i--) if (buffer.readUInt32LE(i) === 0x06054b50) { end = i; break; }
  if (end < 0 || buffer.readUInt16LE(end + 4) || buffer.readUInt16LE(end + 6)) fail('仅支持标准 xlsx 文件');
  const count = buffer.readUInt16LE(end + 10); let p = buffer.readUInt32LE(end + 16), total = 0; const names = new Set();
  if (!count || count > 256) fail('xlsx 文件条目过多');
  try { for (let i = 0; i < count; i++) {
    if (buffer.readUInt32LE(p) !== 0x02014b50) fail('xlsx ZIP 目录无效');
    const flags = buffer.readUInt16LE(p + 8), method = buffer.readUInt16LE(p + 10), compressed = buffer.readUInt32LE(p + 20), size = buffer.readUInt32LE(p + 24), nameLen = buffer.readUInt16LE(p + 28), extra = buffer.readUInt16LE(p + 30), comment = buffer.readUInt16LE(p + 32), local = buffer.readUInt32LE(p + 42);
    const name = buffer.toString('utf8', p + 46, p + 46 + nameLen); if (names.has(name) || name.includes('..') || name.startsWith('/') || /vbaProject|externalLinks/i.test(name)) fail('xlsx 包含不支持的内容'); names.add(name);
    total += size; if (total > MAX_UNCOMPRESSED || flags & 1 || ![0,8].includes(method)) fail('xlsx 解压超过 10MB 或格式不支持');
    if (buffer.readUInt32LE(local) !== 0x04034b50) fail('xlsx ZIP 头无效');
    const start = local + 30 + buffer.readUInt16LE(local + 26) + buffer.readUInt16LE(local + 28); if (start + compressed > buffer.length) fail('xlsx 数据不完整');
    const packed = buffer.subarray(start, start + compressed); const decoded = method === 0 ? packed : zlib.inflateRawSync(packed, { maxOutputLength: MAX_UNCOMPRESSED });
    if (decoded.length !== size) fail('xlsx 解压大小不一致'); p += 46 + nameLen + extra + comment;
  } } catch (e) { if (e.status) throw e; fail('xlsx ZIP 数据无效或超出解压预算'); }
  if (!names.has('[Content_Types].xml') || !names.has('xl/workbook.xml')) fail('仅支持 xlsx 工作簿');
}
async function makeTemplate(credentials) {
  const wb = new ExcelJS.Workbook(); const config = wb.addWorksheet('环境配置');
  const columns = ['environment','importMode','clientId','accId','salt','Remark'];
  config.columns = columns.map(key => ({ header: key, key, width: key === 'salt' ? 30 : 24, style: { numFmt: '@' } }));
  const source = credentials || {};
  config.addRows(['sandbox','production'].flatMap(environment => {
    const rows = Array.isArray(source[environment]) ? source[environment].map(row => row.credentials) : [source[environment] || {}];
    return (rows.length ? rows : [{}]).map(cred => ({ environment, importMode:credentials ? 'replace' : 'merge', clientId:cred.clientId || '', accId:cred.accId || '', salt:cred.salt || '', Remark:cred.remark || '' }));
  }));
  const orders = wb.addWorksheet('订单请求'); orders.columns = ORDER_FIELDS.map(key => ({ header: key, key, width: 24, style: { numFmt: '@' } }));
  // 空白订单模板避免示例数据被误当成真实支付请求。
  orders.addRow(Object.fromEntries(ORDER_FIELDS.map(k => [k, ''])));
  return Buffer.from(await wb.xlsx.writeBuffer());
}
function rowsFromSheet(ws, allowed) {
  if (!ws) return []; if (ws.rowCount > 1000 || ws.columnCount > 40) fail('工作表过大'); const headers = new Map();
  ws.getRow(1).eachCell((c, n) => { if (typeof c.value !== 'string' || !allowed.includes(c.value) || headers.has(c.value)) fail('表头无效或重复'); headers.set(c.value, n); });
  const result = [];
  for (let r = 2; r <= ws.rowCount; r++) {
    const out = {}; const row = ws.getRow(r);
    row.eachCell((c, n) => { if (c.value !== null && ![...headers.values()].includes(n)) fail('发现未知列数据'); });
    for (const [key, n] of headers) { const value = row.getCell(n).value; if (value == null || value === '') { out[key] = ''; continue; } if (!['string','number'].includes(typeof value)) fail('不接受公式、超链接或富文本单元格'); if (TEXT_FIELDS.includes(key) && typeof value !== 'string') fail(`${key} 必须是文本单元格，不能用数字以免精度丢失`); out[key] = String(value).trim(); }
    if (Object.values(out).some(Boolean)) { Object.defineProperty(out,'_excelRow',{value:r,enumerable:false}); result.push(out); }
  }
  return result;
}
function orderFromRow(o) {
  const b = { amount: o.amount, currency: o.currency, merchantTransactionId: o.merchantTransactionId, payResultUrl: o.payResultUrl, payCancelUrl: o.payCancelUrl, notificationUrl: o.notificationUrl, shopperIP: o.shopperIP, captureDelayHours: o.captureDelayHours ? Number(o.captureDelayHours) : 0, customer: { email: o.customerEmail }, goods: [{ name: o.productName, unitPrice: o.unitPrice, number: o.number, virtualProduct: 'N' }] };
  if (o.tradeCountry) b.tradeCountry = o.tradeCountry;
  if (o.paymentMethods) b.paymentMethods = o.paymentMethods.split(',').map(method => method.trim());
  if (o.merchantUserId) b.merchantUserId = o.merchantUserId;
  for (const section of ['shipping','billing']) b[`${section}Address`] = Object.fromEntries(['country','state','city','street','postcode'].map(k => [k, o[section + k[0].toUpperCase() + k.slice(1)]]));
  return b;
}
function json(res, status, data) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(data)); }
function readBody(req, limit = 1500000) { return new Promise((resolve, reject) => { let total = 0; const chunks = []; req.on('data', c => { total += c.length; if (total <= limit) chunks.push(c); }); req.on('end', () => { if (total > limit) return reject(new Error('请求体过大')); try { const b = JSON.parse(Buffer.concat(chunks).toString('utf8')); if (!object(b)) fail('请求体必须为 JSON 对象'); resolve(b); } catch { reject(new Error('JSON 请求格式无效')); } }); req.on('error', reject); }); }
function createApp({ dataDir = ROOT, envVars = process.env, fetchImpl = globalThis.fetch } = {}) {
  let publicIPCache, publicIPPending;
  async function getPublicIP(refresh = false) {
    if (!refresh && publicIPCache && publicIPCache.expiresAt > Date.now()) return publicIPCache.result;
    if (!publicIPPending) publicIPPending = (async () => {
      publicIPCache = undefined;
      const controller = new AbortController();
      let timer;
      const sources = [
        { url:'https://api.ipify.org?format=json', source:'api.ipify.org', json:true },
        { url:'https://api4.ipify.org?format=json', source:'api4.ipify.org', json:true },
        { url:'https://ipv4.icanhazip.com', source:'ipv4.icanhazip.com', json:false }
      ];
      try {
        const deadline = new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(new Error('公网 IP 查询超时')); }, 2500); });
        const queries = sources.map(async source => {
          const response = await fetchImpl(source.url, { method:'GET', headers:{ Accept:source.json ? 'application/json' : 'text/plain' }, redirect:'error', signal:controller.signal });
          if (!response.ok || response.redirected) throw new Error('公网 IP 服务失败');
          const ip = source.json ? (await response.json())?.ip : (await response.text()).trim();
          if (!publicIPv4(ip)) throw new Error('公网 IPv4 无效');
          return { ip, fallback:false, source:source.source };
        });
        const result = await Promise.race([Promise.any(queries), deadline]);
        publicIPCache = { result, expiresAt:Date.now() + 60000 };
        return result;
      } catch {
        return { ip:'', fallback:true, source:'unavailable', notice:'获取失败，请手工填写当前公网 IP' };
      } finally { clearTimeout(timer); controller.abort(); }
    })();
    try { return await publicIPPending; } finally { publicIPPending = undefined; }
  }
  const configFile = path.join(dataDir, 'local-config.json'), ordersFile = path.join(dataDir, 'orders.json');
  const paymentFile = path.join(dataDir, 'payment-config.json'), logsFile = path.join(dataDir, 'order-logs.json');
  const deleteJournal = path.join(dataDir,'order-delete-recovery.json');
  function restoreDeleteJournal() {
    if (!fs.existsSync(deleteJournal)) return;
    const recovery = readJson(deleteJournal);
    if (!object(recovery) || Object.keys(recovery).length !== 2 || recovery.schemaVersion !== 1 || typeof recovery.id !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(recovery.id)) fail('本地删除恢复文件无效，请人工检查',500);
    const orders = readJson(ordersFile,[]), logs = readJson(logsFile,[]);
    if (!Array.isArray(orders) || !Array.isArray(logs) || !orders.every(object) || !logs.every(object)) fail('本地订单或日志格式无效，无法安全恢复删除',500);
    atomicWrite(ordersFile,orders.filter(order => order.id !== recovery.id));
    atomicWrite(logsFile,logs.filter(entry => entry.orderId !== recovery.id));
    fs.unlinkSync(deleteJournal);
  }
  restoreDeleteJournal();
  const activePrepays = new Set();
  let deleteRecoveryRequired = false;
  const paymentSaved = readJson(paymentFile, null);
  const paymentRows = paymentSaved ? validateRows(paymentSaved.rows, CURRENCIES, fail) : DEFAULT_ROWS;
  const existingOrders = readJson(ordersFile, []);
  const saved = readJson(configFile, {}); const state = { env: ENVS.includes(envVars.PINGPONG_ENV) ? envVars.PINGPONG_ENV : 'production', credentials: {}, orders: existingOrders.slice(0, 1000).map(safeOrder), paymentRows, paymentVersion:paymentSaved?.version || 'default-v1', logs:[] };
  if (fs.existsSync(ordersFile) && JSON.stringify(existingOrders) !== JSON.stringify(state.orders)) atomicWrite(ordersFile, state.orders);
  const merchants = createMerchants({state,saved,envVars,fail,persist:next => atomicWrite(configFile,next)});
  const profileFile = path.join(dataDir, 'profile-config.json');
  const profileHelpers = { fail, minor, checkUrl, checkZip };
  const profileSaved = readJson(profileFile, null);
  if (profileSaved && profileSaved.schemaVersion !== 1) fail('资料配置 schemaVersion 不支持');
  state.profileData = profileSaved ? profiles.validateProfiles(profileSaved.data, state.paymentRows, profileHelpers) : profiles.defaults(state.paymentRows);
  state.profileVersion = profileSaved?.version || 'default-v1';
  const publicProfiles = () => ({ schemaVersion:1, version:state.profileVersion, data:JSON.parse(JSON.stringify(state.profileData)) });
  function saveProfiles(input) {
    if (Object.keys(input).some(k => !['data','expectedVersion'].includes(k))) fail('资料配置仅接受 data、expectedVersion');
    if (input.expectedVersion !== undefined && input.expectedVersion !== state.profileVersion) fail('资料版本已变化，请重新加载后保存',409);
    const data = profiles.validateProfiles(input.data,state.paymentRows,profileHelpers), version = crypto.randomUUID();
    atomicWrite(profileFile,{schemaVersion:1,version,data}); state.profileData = data; state.profileVersion = version;
    return publicProfiles();
  }
  async function previewProfiles(base64) {
    const data = await profiles.parseWorkbook(base64,state.paymentRows,profileHelpers);
    return { schemaVersion:1,version:state.profileVersion,data,summary:profiles.summary(data) };
  }
  state.logs = readJson(logsFile, []);
  for (const file of [ordersFile, configFile, paymentFile, logsFile, profileFile]) if (fs.existsSync(file)) fs.chmodSync(file, 0o600);
  function log(entry) { const raw = JSON.parse(JSON.stringify({ id:crypto.randomUUID(), timestamp:new Date().toISOString(), ...entry })); const next = [...state.logs, raw]; atomicWrite(logsFile, next); state.logs = next; }
  function savePaymentConfig(input) {
    if (Object.keys(input).some(k => !['rows'].includes(k))) fail('支付配置只接受 rows 字段');
    const rows = validateRows(input.rows, CURRENCIES, fail), version = crypto.randomUUID();
    if (state.profileVersion !== 'default-v1') profiles.validateProfiles(state.profileData,rows,profileHelpers);
    atomicWrite(paymentFile, { schemaVersion:1, version, rows }); state.paymentRows = rows; state.paymentVersion = version;
    if (state.profileVersion === 'default-v1') state.profileData = profiles.defaults(rows);
    return { rows, version };
  }
  const publicCredential = cred => ({accId:mask(cred.accId),clientId:mask(cred.clientId),configured:Boolean(cred.accId && cred.clientId && cred.salt)});
  const publicConfig = () => ({ env:state.env, environments:ENVS, credentials:Object.fromEntries(ENVS.map(env => [env,{...publicCredential(state.credentials[env]),endpoint:endpoint(env)}])), merchants:Object.fromEntries(ENVS.map(env => [env,state.merchants[env].map(row => ({id:row.id,remark:row.credentials.remark || '',...publicCredential(row.credentials)}))])), selectedMerchantIds:{...state.selectedMerchantIds} });
  function selectMerchant(input) { merchants.select(input); return publicConfig(); }
  function saveOrders(next) { const clean = next.slice(0, 1000).map(safeOrder); atomicWrite(ordersFile, clean); state.orders = clean; }
  function updateOrder(id, patch) { saveOrders(state.orders.map(o => o.id === id ? { ...o, ...patch, updatedAt: new Date().toISOString() } : o)); }
  const handleAction = makeActions({ state, fetchImpl, signBody, verifySign, fail, minor, updateOrder, log, endpoint, checkUrl, orderMerchant:merchants.forOrder });
  function deleteOrder(input) {
    if (deleteRecoveryRequired) fail('本地删除事务需要恢复，请重启应用后再写入',503);
    if (Object.keys(input).some(k => !['id','confirmed'].includes(k)) || typeof input.id !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(input.id) || input.confirmed !== true) fail('删除本地记录必须提供 id 且 confirmed=true');
    const order = state.orders.find(o => o.id === input.id); if (!order) fail('订单不存在',404);
    if (order.status === 'REQUESTING' || order.pendingAction || activePrepays.has(order.id) || handleAction.isBusy(order.id)) fail('订单仍在请求中或存在待确认操作，不能删除本地记录',409);
    const orders = state.orders.filter(o => o.id !== order.id), logs = state.logs.filter(entry => entry.orderId !== order.id);
    try { atomicWrite(deleteJournal,{schemaVersion:1,id:order.id}); }
    catch { fail('本地删除意图保存失败，原记录已保留',500); }
    // 已提交删除意图后，内存也排除目标，避免其他在途订单写入时恢复它。
    state.orders = orders; state.logs = logs;
    try {
      atomicWrite(ordersFile,orders); atomicWrite(logsFile,logs); fs.unlinkSync(deleteJournal);
    } catch {
      deleteRecoveryRequired = true;
      fail('本地删除尚未完成持久化，请重启应用完成恢复；不要重新提交网关操作',500);
    }
    return {deleted:true,id:order.id};
  }
  function saveConfig(b) { merchants.save(b); return publicConfig(); }
  async function importWorkbook(input, strategy = 'file') {
    if (!['file','merge'].includes(strategy)) fail('导入方式无效');
    const files = Array.isArray(input) ? input : [input];
    if (!files.length || (strategy === 'file' && files.length !== 1)) fail('按文件规则恢复时请选择一个工作簿');
    const configRows = [], orderRows = [];
    let totalBytes = 0;
    for (const [index, base64] of files.entries()) {
      try {
        if (typeof base64 !== 'string' || base64.length > Math.ceil(MAX_UPLOAD / 3) * 4 || base64.length % 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) fail('base64 无效或超过 1MB');
        const buffer = Buffer.from(base64, 'base64');
        totalBytes += buffer.length;
        if (totalBytes > 8 * MAX_UPLOAD) fail('所选 Excel 文件合计超过 8 MB，请分批导入');
        checkZip(buffer);
        const wb = new ExcelJS.Workbook();
        try { await wb.xlsx.load(buffer); } catch { fail('xlsx 工作簿无法读取'); }
        const sheet = wb.getWorksheet('环境配置'), orders = wb.getWorksheet('订单请求');
        if (!sheet && !orders) fail('缺少“环境配置”或“订单请求”工作表');
        const rows = rowsFromSheet(sheet, ['environment','importMode','clientId','accId','salt','Remark']);
        if (files.length > 1) for (const row of rows) Object.defineProperty(row,'_fileNumber',{value:index + 1});
        configRows.push(...rows);
        orderRows.push(...rowsFromSheet(orders, ORDER_FIELDS));
        if (orderRows.length > 1) fail('每次导入仅支持一个订单请求行');
      } catch (error) {
        if (files.length > 1) fail(`第 ${index + 1} 个文件：${error.message}`,error.status);
        throw error;
      }
    }
    const next = merchants.importRows(configRows,strategy);
    const order = orderRows[0] || null;
    if (order) validateBiz(orderFromRow(order), state.env, { real: false, rows:state.paymentRows });
    if (next.importedEnvironments.length) merchants.commit(next.merchants,next.selected);
    return { ...publicConfig(), order, importedEnvironments:next.importedEnvironments, importSummary:next.importSummary };
  }
  function testDataFlags(input) {
    return { productionTestMode:input.env === 'production' && input.productionTestMode === true,
      syntheticProfile:input.syntheticProfile === true || input.bizContent?.syntheticProfile === true,
      syntheticAddress:input.syntheticAddress === true || input.bizContent?.syntheticAddress === true };
  }
  function validateProductionData(input) {
    const flags = testDataFlags(input);
    if (input.env === 'production') {
      if (!flags.productionTestMode && flags.syntheticProfile) fail('合成测试资料仅限沙箱；生产联调须明确启用 productionTestMode=true');
      if (!flags.productionTestMode && flags.syntheticAddress) fail('合成测试地址仅限沙箱；生产联调须明确启用 productionTestMode=true');
      if (input.productionConfirmed !== true) fail('生产环境必须明确确认 productionConfirmed=true');
    }
    return flags;
  }
  const elementSessions = new Map();
  const elementMethods = { applePayButton:'ApplePay', googlePayButton:'GooglePay', paypalButton:'PayPal' };
  const contentVersion = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
  function duplicateOrder(env, merchant, merchantTransactionId) {
    return state.orders.some(order => !order.simulated && order.env === env && order.merchantTransactionId === merchantTransactionId && (!order.merchantFingerprint || order.merchantFingerprint === identity(env,merchant.credentials)));
  }
  async function handleSdkSession(input, mode) {
    const label = mode === 'onepage' ? 'OnePage' : 'Elements';
    const env = environment(input.env);
    if (input.mode !== mode || (mode === 'elements' && !Object.hasOwn(elementMethods, input.elementType))) fail(`${label} 模式或支付元素类型无效`);
    const testFlags = validateProductionData(input);
    const b = validateBiz(input.bizContent, env, { rows:state.paymentRows });
    if (!b.tradeCountry || !b.currency) fail(`${label} 必须明确选择国家及币种`);
    let allowedMethods;
    if (mode === 'elements') {
      const method = elementMethods[input.elementType];
      const routeError = validateSelection({ ...b, paymentMethods:[method] }, state.paymentRows);
      if (routeError) fail(`Elements ${method}：${routeError}；请先导入商户已确认的支付配置`);
      if (b.paymentMethods && (b.paymentMethods.length !== 1 || b.paymentMethods[0] !== method)) fail('Elements 支付元素必须与所选支付方式一致且只能选择一项');
      allowedMethods = [method];
    } else {
      allowedMethods = b.paymentMethods || [...new Set(compileRows(state.paymentRows).rules.filter(rule => rule.country === b.tradeCountry && rule.currency === b.currency).map(rule => rule.method))];
      if (!allowedMethods.length) fail('OnePage 没有已明确配置的支付方式，禁止初始化');
    }
    b.paymentMethods = [...allowedMethods];
    const merchant = merchants.resolve(env,input.merchantId), cred = { ...merchant.credentials };
    if (!cred.accId || !cred.clientId || !cred.salt) fail('当前环境配置不完整');
    if (duplicateOrder(env,merchant,b.merchantTransactionId)) fail('订单号已存在，请使用新订单号');
    for (const [id, session] of elementSessions) if (session.expiresAt <= Date.now()) elementSessions.delete(id);
    if (elementSessions.size >= 100) fail('待处理的 SDK 会话过多，请稍后重试',429);
    const sessionId = crypto.randomUUID();
    const session = { ...testFlags, mode, env, merchantId:merchant.id, bizContent:b, bizHash:contentVersion(b), allowedMethods:[...allowedMethods], paymentVersion:state.paymentVersion, credentialVersion:credentialVersion(cred), productionConfirmed:input.productionConfirmed === true, expiresAt:Date.now()+15*60*1000, used:false, ready:false };
    elementSessions.set(sessionId, session);
    const requestTime = new Date().toISOString(), url = new URL('/v4/session/init', endpoint(env)).href;
    const sessionBiz = b.merchantUserId ? { merchantUserId:b.merchantUserId } : {};
    const body = { accId:cred.accId, clientId:cred.clientId, signType:'SHA256', version:'1.0', bizContent:JSON.stringify(sessionBiz) };
    body.sign = signBody(body,cred.salt);
    const entry = { ...testFlags, simulated:false, sessionId, mode, action:'session.init', env, endpoint:url, method:'POST', requestTime, startedAt:requestTime, responseTime:null, request:body };
    let stage = 'connect';
    try {
      const response = await fetchImpl(url,{ method:'POST', headers:{'Content-Type':'application/json',Accept:'application/json'}, body:JSON.stringify(body), redirect:'error', signal:AbortSignal.timeout(15000) });
      entry.httpStatus = response.status || (response.ok ? 200 : 502);
      entry.responseHeadersTime = new Date().toISOString();
      stage = 'read-body';
      let data;
      if (typeof response.text === 'function') { entry.responseText = await response.text(); entry.responseTime = new Date().toISOString(); stage = 'parse-response'; data = JSON.parse(entry.responseText); }
      else { data = await response.json(); entry.responseTime = new Date().toISOString(); }
      stage = 'verify-response';
      entry.response = data; entry.signatureVerified = verifySign(data,cred.salt);
      if (!response.ok) fail(`${label} 初始化 HTTP 响应失败`,502);
      if (!entry.signatureVerified) fail(`${label} 响应验签失败，禁止交付 SDK 凭证`,502);
      if (typeof data.bizContent !== 'string') fail(`${label} 响应 bizContent 必须为原始字符串`,502);
      stage = 'parse-business';
      const biz = JSON.parse(data.bizContent);
      stage = 'validate-business';
      if (!object(biz)) fail(`${label} 响应业务格式无效`,502);
      for (const source of [data,biz]) for (const key of ['accId','clientId']) if (source[key] !== undefined && source[key] !== cred[key]) fail(`${label} 响应商户身份不匹配`,502);
      if (data.code !== '000000') fail(`${label} 初始化失败（${String(data.code)}）`,502);
      if (typeof biz.sdkAccessToken !== 'string' || !biz.sdkAccessToken.trim()) fail(`${label} 未返回有效 sdkAccessToken`,502);
      session.ready = true;
      const sdkUrl = mode === 'onepage' ? `https://payssr-cdn.pingpongx.com/production-fra/acquirer-checkout-onepage/${env === 'sandbox' ? 'sandbox/' : ''}pp-checkout.js` : `https://acquirer-cdn.pingpongx.com/acquirer/components/sdk/${env}/v1/index.js`;
      return { sessionId, merchantId:merchant.id, productionTestMode:session.productionTestMode, sdkAccessToken:biz.sdkAccessToken, accId:cred.accId, env, region:'fra', sdkUrl, ...(mode === 'onepage' ? {allowedMethods:[...allowedMethods]} : {}) };
    } catch (e) {
      elementSessions.delete(sessionId);
      const cause = e.cause || e;
      const code = typeof cause.code === 'string' ? cause.code : (e.name === 'TimeoutError' || e.name === 'AbortError') ? 'REQUEST_TIMEOUT' : 'UNKNOWN';
      entry.errorStage = stage;
      entry.errorCode = code;
      entry.errorDetail = { name:e.name, message:e.message, cause: e.cause ? {name:cause.name, code:cause.code, message:cause.message} : undefined };
      let reason;
      if (e.status) reason = e.message;
      else if (stage === 'parse-response' || stage === 'parse-business' || e.name === 'SyntaxError') reason = `${label} 初始化响应 JSON 无法解析（HTTP ${entry.httpStatus || '未知'}）`;
      else if (stage === 'read-body') reason = `${label} 已收到 HTTP ${entry.httpStatus} 响应头，但响应正文读取失败（${code}）`;
      else if (code === 'ECONNRESET' && /TLS|secure/i.test(cause.message || '')) reason = `${label} 初始化连接在 TLS 握手完成前被断开（ECONNRESET），未收到 HTTP 响应；请检查当前网络或代理`;
      else if (['ENOTFOUND','EAI_AGAIN'].includes(code)) reason = `${label} 初始化域名解析失败（${code}），请检查 DNS 或代理`;
      else if (code.includes('TIMEOUT') || code === 'ETIMEDOUT') reason = `${label} 初始化请求超时（${code}），未收到 HTTP 响应；请检查网络或代理`;
      else reason = `${label} 初始化网络连接失败（${code}），未收到 HTTP 响应；请检查网络、代理或 TLS 证书`;
      entry.error = reason;
      const error = new Error(reason); error.status = e.status || 502; error.sessionId = sessionId; throw error;
    } finally { entry.completedAt = new Date().toISOString(); entry.durationMs = Date.parse(entry.completedAt) - Date.parse(requestTime); log(entry); }
  }
  async function handleSdkOrder(input, mode) {
    const label = mode === 'onepage' ? 'OnePage' : 'Elements';
    if (Object.keys(input).some(key => !['sessionId','payMethod','productionTestMode','merchantId'].includes(key))) fail(`${label} 下单只接受 sessionId、payMethod、productionTestMode、merchantId`);
    const session = elementSessions.get(input.sessionId);
    if (!session?.ready || session.mode !== mode || session.expiresAt <= Date.now()) fail(`${label} 会话已失效或模式不匹配，请重新初始化`,409);
    if (session.used) fail(`${label} 会话已发起过下单，请先查询原订单，不可重复提交`,409);
    if (!session.allowedMethods.includes(input.payMethod)) fail('SDK 支付方式与初始化的支付候选不匹配');
    if ((input.productionTestMode === undefined ? false : input.productionTestMode) !== session.productionTestMode) fail('SDK 下单 productionTestMode 与初始化会话不一致');
    if (input.merchantId !== undefined && input.merchantId !== session.merchantId) fail('SDK 会话商户不匹配，请重新初始化',409);
    if (state.selectedMerchantIds[session.env] !== session.merchantId) fail('当前商户已切换，请重新初始化 SDK',409);
    if (credentialVersion(merchants.resolve(session.env,session.merchantId).credentials) !== session.credentialVersion) fail(`商户配置已变化，请重新初始化 ${label}`,409);
    if (state.paymentVersion !== session.paymentVersion) fail(`支付配置已变化，请重新初始化 ${label}`,409);
    if (contentVersion(session.bizContent) !== session.bizHash) fail('冻结订单内容已变化，请重新初始化',409);
    session.used = true;
    const bizContent = { ...session.bizContent, paymentMethods:[input.payMethod] };
    return handlePrepay({ env:session.env, merchantId:session.merchantId, mode, productionConfirmed:session.productionConfirmed, productionTestMode:session.productionTestMode, syntheticProfile:session.syntheticProfile, syntheticAddress:session.syntheticAddress, bizContent }, { sessionId:input.sessionId });
  }
  const handleElementSession = input => handleSdkSession(input, 'elements');
  const handleElementOrder = input => handleSdkOrder(input, 'elements');
  const handleOnepageSession = input => handleSdkSession(input, 'onepage');
  const handleOnepageOrder = input => handleSdkOrder(input, 'onepage');
  async function handlePrepay(input, elementContext) {
    const env = environment(input.env);
    const testFlags = validateProductionData(input);
    if (!['embedded','redirect'].includes(input.mode) && !(['elements','onepage'].includes(input.mode) && elementContext?.sessionId)) fail('mode 无效'); const b = validateBiz(input.bizContent, env, { rows:state.paymentRows }); const merchant = merchants.resolve(env,input.merchantId), cred = { ...merchant.credentials }; if (!cred.accId || !cred.clientId || !cred.salt) fail('当前环境配置不完整');
    if (duplicateOrder(env,merchant,b.merchantTransactionId)) fail('订单号已存在，请使用新订单号');
    const body = { accId: cred.accId, clientId: cred.clientId, signType: 'SHA256', version: '1.0', bizContent: JSON.stringify(b) }; body.sign = signBody(body, cred.salt);
    const order = { ...testFlags, simulated:false, id: crypto.randomUUID(), merchantTransactionId: b.merchantTransactionId, env, amount: b.amount, currency: b.currency, tradeCountry:b.tradeCountry, paymentMethods:b.paymentMethods, merchantId:merchant.id, merchantFingerprint:identity(env, cred), notificationUrl:b.notificationUrl, mode: input.mode, requestSummary: { merchantTransactionId:b.merchantTransactionId, amount:b.amount, currency:b.currency, tradeCountry:b.tradeCountry, captureDelayHours:b.captureDelayHours }, status: 'REQUESTING', createdAt: new Date().toISOString() }; saveOrders([order, ...state.orders]);
    activePrepays.add(order.id);
    const requestTime = new Date().toISOString();
    const entry = { ...testFlags, simulated:false, orderId:order.id, ...(elementContext ? { sessionId:elementContext.sessionId } : {}), action:'prepay', env, endpoint:endpoint(env), method:'POST', request:body, requestTime, startedAt:requestTime, responseTime:null };
    try {
      if (elementContext) {
        const linked = state.logs.map(item => item.sessionId === elementContext.sessionId ? { ...item, orderId:order.id } : item);
        atomicWrite(logsFile, linked); state.logs = linked;
      }
      const response = await fetchImpl(endpoint(env), { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body), redirect: 'error', signal: AbortSignal.timeout(20000) });
      entry.httpStatus = response.status || (response.ok ? 200 : 502);
      let data;
      if (typeof response.text === 'function') {
        entry.responseText = await response.text(); entry.responseTime = new Date().toISOString();
        data = JSON.parse(entry.responseText);
      } else { data = await response.json(); entry.responseTime = new Date().toISOString(); }
      entry.response = data; entry.signatureVerified = verifySign(data, cred.salt);
      if (!response.ok) fail('支付服务 HTTP 响应失败');
      if (!entry.signatureVerified) fail('响应签名缺失或验签失败，禁止交付支付会话');
      for (const key of ['accId','clientId']) if (data[key] !== undefined && data[key] !== cred[key]) fail('响应商户身份不匹配');
      let biz = {};
      if (data.bizContent !== undefined && data.bizContent !== null && data.bizContent !== '') {
        if (typeof data.bizContent !== 'string') fail('响应 bizContent 必须是原始字符串');
        biz = JSON.parse(data.bizContent); if (!object(biz)) fail('响应 bizContent 无效');
      } else if (data.code === '000000') fail('响应 bizContent 必须是原始字符串');
      for (const key of ['accId','clientId']) if (biz[key] !== undefined && biz[key] !== cred[key]) fail('响应商户身份不匹配');
      if (biz.merchantTransactionId !== undefined && biz.merchantTransactionId !== b.merchantTransactionId) fail('响应订单号不匹配');
      if (data.code !== '000000') {
        if (state.orders.find(o => o.id === order.id)?.status === 'REQUESTING') updateOrder(order.id, { status:'FAILED', responseSummary: { code:data.code, signatureVerified:true } });
        return { code:data.code, description:typeof data.description === 'string' ? data.description : '', bizContent:{}, _meta:{env,orderId:order.id,signatureVerified:true} };
      }
      if (state.orders.find(o => o.id === order.id)?.status === 'REQUESTING') updateOrder(order.id, { responseSummary:{ code:data.code, signatureVerified:true }, status: data.code === '000000' ? 'CREATED' : 'FAILED', ...(typeof biz.transactionId === 'string' ? { transactionId: biz.transactionId } : {}) });
      const delivered = {}; if (data.code === '000000') for (const key of ['token','paymentUrl','innerJsUrl','transactionId','merchantTransactionId']) if (typeof biz[key] === 'string') delivered[key] = biz[key];
      return { code: data.code, description: typeof data.description === 'string' ? data.description : '', bizContent: delivered, _meta: { env, orderId: order.id, signatureVerified: true } };
    } catch (e) { entry.error = e.status ? e.message : '支付请求失败或响应无法解析'; if (state.orders.find(o => o.id === order.id)?.status === 'REQUESTING') updateOrder(order.id, { status: 'UNKNOWN' }); if (e.status) throw e; fail('支付请求失败或响应无效；请核对服务端状态后再发起新请求', 502); }
    finally { try { entry.completedAt = new Date().toISOString(); log(entry); } finally { activePrepays.delete(order.id); } }
  }
  function mock(input, requestTime = new Date().toISOString()) {
    const env = environment(input.env); if (!['redirect','embedded'].includes(input.mode)) fail('mode 无效');
    const b = validateBiz(input.bizContent, env, { real:false, rows:state.paymentRows });
    const merchant = input.merchantId || state.selectedMerchantIds[env] ? merchants.resolve(env,input.merchantId) : null;
    const order = { id:crypto.randomUUID(), ...(merchant && {merchantId:merchant.id,merchantFingerprint:identity(env,merchant.credentials)}), merchantTransactionId:b.merchantTransactionId, env, amount:b.amount, currency:b.currency, tradeCountry:b.tradeCountry, paymentMethods:b.paymentMethods, mode:input.mode, status:'SIMULATED', simulated:true, createdAt:new Date().toISOString(), requestSummary:{ merchantTransactionId:b.merchantTransactionId, amount:b.amount, currency:b.currency, tradeCountry:b.tradeCountry, captureDelayHours:b.captureDelayHours } };
    saveOrders([order, ...state.orders]);
    const response = { code:'MOCK', bizContent:{ merchantTransactionId:b.merchantTransactionId, amount:b.amount, currency:b.currency }, simulated:true, orderId:order.id, _meta:{ env, orderId:order.id, simulated:true } };
    const responseTime = new Date().toISOString();
    log({ orderId:order.id, action:'mock', env, endpoint:'/api/mock', method:'POST', requestTime, startedAt:requestTime, responseTime, completedAt:responseTime, request:input, response, signatureVerified:false, simulated:true });
    return response;
  }
  const server = http.createServer(async (req, res) => {
    const requestTime = new Date().toISOString();
    let audit;
    function reply(status, data) {
      if (audit) { audit.responseTime = new Date().toISOString(); audit.response = data; audit.httpStatus = status; }
      return json(res, status, data);
    }
    try {
      const host = req.headers.host; const port = server.address()?.port; if (![`localhost:${port}`, `127.0.0.1:${port}`].includes(host)) return json(res, 403, { error: 'Host 不在本地允许列表' });
      const url = new URL(req.url, `http://${host}`); const notify = /^\/api\/notify\/(sandbox|production)$/.test(url.pathname);
      // Only document navigation may cross from Pages. All API traffic stays on loopback.
      const embedded = url.pathname === '/pages';
      const topLevelHome = ['/', '/index.html'].includes(url.pathname) && req.headers['sec-fetch-dest'] === 'document';
      let pagesEmbed = false;
      if (embedded && req.headers['sec-fetch-dest'] === 'iframe') {
        try {
          const from = new URL(req.headers.referer);
          pagesEmbed = from.origin === PAGES && ['/checkout-offline-demo/', '/checkout-offline-demo/index.html'].includes(from.pathname);
        } catch {}
        if (!pagesEmbed) return json(res, 403, {error:'请从本站 Pages 入口打开本机工作区'});
      }
      const entryNavigation = req.method === 'GET' && req.headers['sec-fetch-mode'] === 'navigate' && (topLevelHome || pagesEmbed);
      res.setHeader('Content-Security-Policy', 'frame-ancestors ' + (embedded || url.pathname === '/sdk-host.html' ? "'self' " + PAGES : "'self'"));
      if (!notify && !entryNavigation && ((req.headers.origin && req.headers.origin !== `http://${host}`) || req.headers['sec-fetch-site'] === 'cross-site')) return json(res, 403, { error: '禁止跨源访问' });
      if (req.method === 'POST' && deleteRecoveryRequired) fail('本地删除事务需要恢复，请重启应用后再写入',503);
      if (req.method === 'POST' && !notify && req.headers.origin !== `http://${host}`) return json(res, 403, { error: '写操作需要同源 Origin' });
      if (req.method === 'GET' && url.pathname === '/api/public-ip') return json(res, 200, await getPublicIP(url.searchParams.get('refresh') === '1'));
      if (req.method === 'GET' && url.pathname === '/api/test-address') return json(res, 200, testAddress(url.searchParams.get('country')));
      if (req.method === 'GET' && url.pathname === '/api/config') return json(res, 200, publicConfig());
      if (req.method === 'GET' && url.pathname === '/api/orders') return json(res, 200, { orders: state.orders.map(o => { const { notificationUrl, ...publicOrder } = o; return publicOrder; }), limit: 1000 });
      if (req.method === 'GET' && url.pathname === '/api/elements/logs') {
        const sessionId = url.searchParams.get('sessionId');
        if (typeof sessionId !== 'string' || !/^[a-f0-9-]{36}$/.test(sessionId)) fail('Elements 会话ID无效');
        const logs = state.logs.filter(entry => entry.sessionId === sessionId);
        if (!logs.length) fail('Elements 会话日志不存在',404);
        return json(res,200,{sessionId,logs});
      }
      if (req.method === 'GET' && url.pathname === '/api/orders/logs') {
        const id = url.searchParams.get('id'); if (!state.orders.some(o => o.id === id)) fail('订单不存在', 404);
        return json(res, 200, { logs:state.logs.filter(x => x.orderId === id), notice:'新日志完整保留原始请求与响应（含签名、token和买家资料），请妥善保管本机文件；旧日志已脱敏字段和未记录内容无法恢复。' });
      }
      if (req.method === 'GET' && url.pathname === '/api/profiles') return json(res,200,publicProfiles());
      if (req.method === 'GET' && ['/api/profiles/template.xlsx','/api/profiles/export.xlsx'].includes(url.pathname)) {
        const template = url.pathname.endsWith('/template.xlsx');
        const bytes = await profiles.workbook(template ? profiles.defaults(state.paymentRows) : state.profileData);
        res.writeHead(200,{ 'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-Disposition':`attachment; filename="profiles-${template ? 'template' : 'export'}.xlsx"`,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff' }); return res.end(bytes);
      }
      if (req.method === 'GET' && url.pathname === '/api/payment-config') return json(res, 200, { rows:state.paymentRows, version:state.paymentVersion });
      if (req.method === 'GET' && ['/api/payment-config/export','/api/payment-config/template'].includes(url.pathname)) { const template = url.pathname.endsWith('/template'); res.setHeader('Content-Disposition', `attachment; filename="payment-config${template ? '-template' : ''}.json"`); return json(res, 200, { schemaVersion:1, rows:template ? DEFAULT_ROWS : state.paymentRows }); }
      if (req.method === 'GET' && ['/api/template.xlsx','/api/config/export.xlsx'].includes(url.pathname)) { const exporting = url.pathname === '/api/config/export.xlsx'; const bytes = await makeTemplate(exporting ? state.merchants : undefined); res.writeHead(200, { 'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': `attachment; filename="pingpong-${exporting ? 'environment-export' : 'checkout-template'}.xlsx"`, 'Cache-Control': 'no-store', 'X-Content-Type-Options':'nosniff' }); return res.end(bytes); }
      if (req.method === 'POST') {
        if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) fail('需要 application/json', 415); const b = await readBody(req, url.pathname === '/api/import' ? 12 * MAX_UPLOAD : undefined);
        if (url.pathname === '/api/profiles') return json(res,200,saveProfiles(b));
        if (url.pathname === '/api/profiles/preview') return json(res,200,await previewProfiles(b.base64));
        if (url.pathname === '/api/payment-config') return json(res, 200, savePaymentConfig(b));
        if (url.pathname === '/api/orders/delete') return json(res,200,deleteOrder(b));
        if (url.pathname === '/api/orders/action') return json(res, 200, await handleAction(b));
        if (url.pathname === '/api/config/select') return json(res,200,selectMerchant(b));
        if (url.pathname === '/api/config/edit') {
          const env = environment(b.env);
          if (b.merchantId === '' || (b.merchantId === undefined && !state.selectedMerchantIds[env])) return json(res,200,{env,merchantId:'',credentials:{accId:'',clientId:'',salt:'',remark:''}});
          const merchant = merchants.resolve(env,b.merchantId);
          return json(res, 200, { env, merchantId:merchant.id, credentials:{ ...merchant.credentials } });
        }
        if (url.pathname === '/api/config') return json(res, 200, saveConfig(b));
        if (url.pathname === '/api/env') { state.env = environment(b.env); return json(res, 200, publicConfig()); }
        if (url.pathname === '/api/import') return json(res, 200, await importWorkbook(b.files ?? b.base64,b.strategy));
        if (url.pathname === '/api/onepage/session') return json(res,200,await handleOnepageSession(b));
        if (url.pathname === '/api/onepage/order') return json(res,200,await handleOnepageOrder(b));
        if (url.pathname === '/api/elements/session') return json(res,200,await handleElementSession(b));
        if (url.pathname === '/api/elements/order') return json(res,200,await handleElementOrder(b));
        if (url.pathname === '/api/prepay') return json(res, 200, await handlePrepay(b));
        if (url.pathname === '/api/mock') return json(res, 200, mock(b, requestTime));
        if (url.pathname === '/api/mock-result') {
          if (!['SIMULATED_SUCCESS','SIMULATED_FAILED','SIMULATED_CANCELLED'].includes(b.status)) fail('模拟状态无效');
          const o = state.orders.find(x => x.id === b.id); if (!o || !o.simulated) fail('仅允许更新已有模拟订单');
          audit = { orderId:o.id, action:'mock', env:o.env, endpoint:url.pathname, method:req.method, requestTime, startedAt:requestTime, responseTime:null, request:b, simulated:true };
          updateOrder(o.id, { status:b.status });
          return reply(200, { ok:true, order:state.orders.find(x => x.id === o.id) });
        }
        if (notify) {
          if (url.search) fail('通知路径不能带 query');
          const env = environment(url.pathname.split('/').pop());
          const verifiedMerchants = state.merchants[env].filter(merchant => verifySign(b,merchant.credentials.salt));
          audit = { action:'notify', env, endpoint:url.pathname, method:req.method, requestTime, startedAt:requestTime, responseTime:null, request:b, signatureVerified:verifiedMerchants.length > 0, merchantMatched:false };
          if (typeof b.bizContent !== 'string') fail('通知 bizContent 必须为签名原始字符串');
          let biz; try { biz = JSON.parse(b.bizContent); } catch { fail('通知 bizContent JSON 无效'); } if (!object(biz)) fail('通知内容无效');
          const candidates = state.orders.filter(order => !order.simulated && order.env === env && order.merchantTransactionId === biz.merchantTransactionId).flatMap(order => {
            let merchant; try { merchant = merchants.forOrder(order); } catch { return []; }
            const cred = merchant.credentials;
            if ([b,biz].some(source => ['accId','clientId'].some(key => source[key] !== undefined && source[key] !== cred[key])) || !verifiedMerchants.some(row => row.id === merchant.id)) return [];
            return [{order,merchant}];
          });
          if (candidates.length !== 1) fail('通知签名、商户身份或原订单绑定缺失、不匹配或存在歧义');
          const {order:o,merchant} = candidates[0], cred = merchant.credentials;
          audit.orderId = o.id; audit.merchantId = merchant.id; audit.merchantMatched = true;
          if (biz.notifyType !== 'RECHARGE' || !['SUCCESS','FAILED','CANCEL','AUTH_SUCCESS'].includes(biz.status) || typeof biz.transactionId !== 'string' || !biz.transactionId || typeof biz.requestId !== 'string' || !biz.requestId) fail('通知类型、状态或交易标识不受支持');
          if (o && (typeof o.currency !== 'string' || !o.currency.trim())) fail('原订单未指定币种，无法核对通知付款币种，拒绝自动确认；需人工核实');
          const normalizedAmount = typeof biz.amount === 'string' ? biz.amount.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '') : biz.amount;
          if (!o || o.currency !== biz.currency || minor(o.amount, o.currency, 'amount') !== minor(normalizedAmount, o.currency, 'amount') || (o.transactionId && o.transactionId !== biz.transactionId)) fail('通知订单、环境、金额或币种不匹配');
          const status = biz.status;
          audit.response = { received:true }; audit.businessStatus = status;
          if (o.status === status || (o.notificationRequestId === biz.requestId && o.notificationStatus === biz.status)) { audit.response.duplicate = true; return reply(200, audit.response); }
          const oldStatus = { PAID:'SUCCESS', CANCELLED:'CANCEL', AUTHORIZED:'AUTH_SUCCESS' }[o.status] || o.status;
          if (['SUCCESS','CANCEL','CLOSED'].includes(oldStatus) || (oldStatus === 'AUTH_SUCCESS' && !['SUCCESS','CANCEL'].includes(status))) fail('通知试图回退已确认状态', 409);
          updateOrder(o.id, { status, transactionId:biz.transactionId, notificationRequestId:biz.requestId, notificationStatus:biz.status });
          return reply(200, { received:true });
        }
      }
      const staticFiles = { '/':'index.html', '/pages':'index.html', '/index.html':'index.html', '/app.js':'app.js', '/sdk-host.html':'sdk-host.html', '/sdk-host.js':'sdk-host.js', '/checkout-options.js':'checkout-options.js', '/styles.css':'styles.css' };
      if (req.method !== 'GET' || !Object.hasOwn(staticFiles, url.pathname)) return json(res, 404, { error: 'Not found' });
      const file = staticFiles[url.pathname]; res.writeHead(200, { 'Content-Type': { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8' }[path.extname(file)], 'X-Content-Type-Options':'nosniff', 'Cache-Control':'no-store' }); res.end(fs.readFileSync(path.join(ROOT, file)));
    } catch (e) { if (audit) { audit.error = e.message || '请求失败'; } if (!res.headersSent) reply(e.status || 400, { error:e.message || '请求失败', ...(e.sessionId ? {sessionId:e.sessionId} : {}) }); else res.end(); }
    finally { if (audit) { audit.completedAt = new Date().toISOString(); log(audit); } }
  });
  server.requestTimeout = 25000;
  return { server, state, publicConfig, saveConfig, selectMerchant, importWorkbook, handlePrepay, handleElementSession, handleElementOrder, handleOnepageSession, handleOnepageOrder, mock, handleAction, savePaymentConfig, publicProfiles, saveProfiles, previewProfiles, deleteOrder };
}
function loadDotEnv() { const file = path.join(ROOT, '.env'); if (!fs.existsSync(file)) return; for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) { const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, ''); } }
if (require.main === module) { loadDotEnv(); const port = Number(process.env.PORT || 8787); createApp().server.listen(port, '127.0.0.1', () => console.log(`本地服务已启动：127.0.0.1:${port}`)); }
module.exports = { createApp, signBody, verifySign, validateBiz, makeTemplate, checkZip, safeOrder, ORDER_FIELDS };
