'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {createApp} = require('./server');
const {version} = require('./package.json');

const dataDir = process.env.CHECKOUT_DATA_DIR || path.join(os.homedir(), '.pingpong-checkout-h5');
fs.mkdirSync(dataDir, {recursive:true, mode:0o700});
const envFile = path.join(dataDir,'.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);
const port = Number(process.env.PORT || 18791);
const url = 'http://127.0.0.1:' + port + '/';
const {server} = createApp({dataDir});
function openBrowser() {
  if (process.env.CHECKOUT_NO_OPEN === '1') return;
  const command = {darwin:'open',win32:'rundll32',linux:'xdg-open'}[process.platform];
  if (!command) return;
  const args = process.platform === 'win32' ? ['url.dll,FileProtocolHandler',url] : [url];
  const child = spawn(command, args, {detached:true, stdio:'ignore'});
  child.on('error', () => console.log('请在浏览器中打开', url));
  child.unref();
}

server.on('error', async error => {
  if (error.code === 'EADDRINUSE') {
    try {
      const res = await fetch(url, {redirect:'error',signal:AbortSignal.timeout(2000)});
      const html = res.ok && await res.text();
      if (html && html.includes('<meta name="checkout-local" content="'+version+'">')) {
        console.log('本机联调台已启动', url); openBrowser(); return;
      }
    } catch {}
    console.error('端口', port, '已被其他程序占用。请关闭占用该端口的程序后重试。');
  } else console.error(error.message);
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  console.log('PingPong Checkout v'+version+' · 本机联调台\n'+url+'\n数据目录 '+dataDir+'\n保留此窗口以运行服务，按 Ctrl+C 停止。');
  openBrowser();
});
