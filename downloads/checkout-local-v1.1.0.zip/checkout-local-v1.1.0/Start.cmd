@echo off
cd /d "%~dp0"
where node >nul 2>nul
if not errorlevel 1 (
  node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 22 ? 0 : 1)"
  if not errorlevel 1 goto ready
)
echo Install Node.js 22 or newer from https://nodejs.org/ and reopen this file.
pause
exit /b 1
:ready
node start.cjs
if errorlevel 1 pause
