'use strict';
const crypto = require('node:crypto');
const { identity } = require('./order-actions');
const ENVS = ['production', 'sandbox'];
const empty = () => ({ accId:'', clientId:'', salt:'' });
const credentialVersion = cred => crypto.createHash('sha256').update(JSON.stringify([cred.accId, cred.clientId, cred.salt])).digest('hex');
function createMerchants({ state, saved, envVars, fail, persist }) {
  const validEnv = env => { if (!ENVS.includes(env)) fail('环境必须为 production 或 sandbox'); return env; };
  const legacyId = (env, cred) => `merchant-${identity(env, cred).slice(0,32)}`;
  state.merchants = {}; state.selectedMerchantIds = {};
  for (const env of ENVS) {
    const prefix = `PINGPONG_${env.toUpperCase()}_`;
    const initial = { accId:envVars[`${prefix}ACCID`] || '', clientId:envVars[`${prefix}CLIENTID`] || '', salt:envVars[`${prefix}SALT`] || '', ...(envVars[`${prefix}REMARK`] ? {remark:envVars[`${prefix}REMARK`]} : {}) };
    const credentials = { ...initial, ...(saved.credentials?.[env] || saved[env] || {}) };
    const list = saved.schemaVersion === 2 ? saved.merchants?.[env] : [{ id:legacyId(env, credentials), credentials }];
    if (!Array.isArray(list) || list.some(row => !row || typeof row.id !== 'string' || !row.id || !row.credentials || ['accId','clientId','salt'].some(k => typeof row.credentials[k] !== 'string') || (row.credentials.remark !== undefined && (typeof row.credentials.remark !== 'string' || row.credentials.remark.length > 500))) || new Set(list.map(row => row.id)).size !== list.length || new Set(list.map(row => identity(env,row.credentials))).size !== list.length) fail('本地商户配置无效',500);
    state.merchants[env] = structuredClone(list);
    state.selectedMerchantIds[env] = list.some(row => row.id === saved.selectedMerchantIds?.[env]) ? saved.selectedMerchantIds[env] : list[0]?.id || '';
  }
  // 兼容已有调用与测试直接修改 state.credentials；始终指向当前商户。
  state.credentials = {};
  for (const env of ENVS) Object.defineProperty(state.credentials, env, { enumerable:true, get() { return state.merchants[env].find(row => row.id === state.selectedMerchantIds[env])?.credentials || empty(); }, set(credentials) {
    let row = state.merchants[env].find(row => row.id === state.selectedMerchantIds[env]);
    if (!row) { row = {id:legacyId(env,credentials),credentials}; state.merchants[env].push(row); state.selectedMerchantIds[env] = row.id; }
    row.credentials = credentials;
  } });
  function resolve(env, merchantId) {
    validEnv(env);
    const id = merchantId === undefined ? state.selectedMerchantIds[env] : merchantId;
    if (typeof id !== 'string') fail('merchantId 必须为文本');
    const row = state.merchants[env].find(item => item.id === id);
    if (!row) fail('商户不存在或已被移除，请重新选择',409);
    return row;
  }
  function commit(merchants, selectedMerchantIds) {
    persist({schemaVersion:2,merchants,selectedMerchantIds});
    state.merchants = merchants; state.selectedMerchantIds = selectedMerchantIds;
  }
  function select({env,merchantId}) {
    if (typeof merchantId !== 'string' || !merchantId) fail('选择商户必须提供 merchantId');
    const row = resolve(env,merchantId);
    commit(state.merchants,{...state.selectedMerchantIds,[env]:row.id});
  }
  function save(input) {
    const env = validEnv(input.env), adding = input.merchantId === '' || (input.merchantId === undefined && !state.selectedMerchantIds[env]);
    const old = adding ? {id:crypto.randomUUID(),credentials:empty()} : resolve(env,input.merchantId);
    const credentials = {...old.credentials};
    for (const key of ['accId','clientId','salt','remark']) {
      if (input[key] !== undefined && typeof input[key] !== 'string') fail(`${key} 必须是文本`);
      const value = input[key]?.trim();
      if (key === 'remark' && value?.length > 500) fail('remark 不能超过 500 字符');
      if (key === 'remark' && input[key] !== undefined) credentials[key] = value;
      else if (value) { if (value.includes('••••')) fail('不能保存脱敏占位符，请输入完整凭据或留空保留原值'); credentials[key] = value; }
    }
    if (state.merchants[env].some(row => row.id !== old.id && identity(env,row.credentials) === identity(env,credentials))) fail('同环境已存在相同 accId/clientId 商户',409);
    const rows = adding ? [...state.merchants[env],{id:old.id,credentials}] : state.merchants[env].map(row => row.id === old.id ? {id:old.id,credentials} : row);
    commit({...state.merchants,[env]:rows},{...state.selectedMerchantIds,[env]:old.id});
  }
  function importRows(rows) {
    const merchants = structuredClone(state.merchants), selected = {...state.selectedMerchantIds}, groups = new Map(), duplicateRows = [];
    for (const [index,row] of rows.entries()) {
      const env = validEnv(row.environment), mode = row.importMode || 'merge';
      if (row.Remark?.length > 500) fail('Remark 不能超过 500 字符');
      if (!['merge','replace'].includes(mode)) fail('环境 importMode 仅支持 merge、replace 或留空');
      if (mode === 'merge' && !row.accId && !row.clientId && !row.salt && !row.Remark) continue;
      if (!groups.has(env)) groups.set(env,{mode,rows:[]});
      const group = groups.get(env);
      if (group.mode !== mode) fail('同一环境不能混用 merge 与 replace');
      const duplicate = group.rows.find(item => item.accId === row.accId && item.clientId === row.clientId);
      if (duplicate) {
        const firstRow = duplicate._excelRow ?? rows.indexOf(duplicate) + 2, duplicateRow = row._excelRow ?? index + 2;
        if (['accId','clientId','salt','Remark'].some(key => duplicate[key] !== row[key])) fail(`环境配置第 ${firstRow}、${duplicateRow} 行重复商户身份但配置内容冲突，请统一后重试`);
        duplicateRows.push({environment:env,firstRow,duplicateRow});
        continue;
      }
      group.rows.push(row);
    }
    for (const [env,group] of groups) {
      const oldRows = state.merchants[env], next = group.mode === 'replace' ? [] : merchants[env];
      for (const row of group.rows) {
        const matches = oldRows.filter(item => item.credentials.accId === row.accId && item.credentials.clientId === row.clientId);
        if (matches.length > 1) fail('商户身份存在歧义，无法导入');
        const old = matches[0];
        if (group.mode === 'replace' && !['accId','clientId','salt'].every(key => Object.hasOwn(row,key))) fail('完整恢复必须包含所有凭据列');
        if (group.mode === 'merge' && (!row.accId || !row.clientId || (!row.salt && !old?.credentials.salt))) fail('环境凭据不完整；仅匹配商户允许保留原 salt');
        for (const key of ['accId','clientId','salt']) if (row[key]?.includes('••••')) fail('不能导入脱敏占位符');
        const credentials = { accId:row.accId, clientId:row.clientId, salt:group.mode === 'replace' ? row.salt : row.salt || old.credentials.salt };
        if (Object.hasOwn(row,'Remark')) { if (row.Remark) credentials.remark = row.Remark; }
        else if (group.mode === 'merge' && old?.credentials.remark !== undefined) credentials.remark = old.credentials.remark;
        const item = {id:old?.id || crypto.randomUUID(),credentials}, index = next.findIndex(existing => existing.id === item.id);
        if (index < 0) next.push(item); else next[index] = item;
      }
      merchants[env] = next;
      if (!next.some(row => row.id === selected[env])) selected[env] = next[0]?.id || '';
      const current = next.find(row => row.id === selected[env]);
      if (group.mode === 'merge' && current && ['accId','clientId','salt'].every(key => !current.credentials[key])) {
        selected[env] = next.find(row => ['accId','clientId','salt'].every(key => row.credentials[key]))?.id || selected[env];
      }
    }
    return {merchants,selected,importedEnvironments:[...groups.keys()],importSummary:{merchantCount:[...groups.values()].reduce((sum,group)=>sum+group.rows.length,0),duplicateRows}};
  }
  function forOrder(order) {
    validEnv(order.env);
    if (!order.merchantFingerprint) fail('旧历史缺少商户身份绑定，无法安全确定原商户；请人工核实',409);
    const matches = state.merchants[order.env].filter(row => identity(order.env,row.credentials) === order.merchantFingerprint && (!order.merchantId || row.id === order.merchantId));
    if (matches.length !== 1) fail('原订单商户身份缺失、已变化或存在歧义，禁止操作',409);
    return matches[0];
  }
  return {resolve,commit,select,save,importRows,forOrder};
}
module.exports = {createMerchants,credentialVersion};
