#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if command -v node >/dev/null 2>&1 && node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)'; then
  exec node start.cjs
fi
version=v22.23.5
case "$(uname -s)-$(uname -m)" in
  Darwin-arm64) platform=darwin-arm64; sum=e7131995759b61a0170b646010d2ad35a5d37b4cb0d471f3e8317eac6f742f3d ;;
  Darwin-x86_64) platform=darwin-x64; sum=c53383238206b9ae4db23c5d8a63645e2e753bec8ab51a49cc81939aa64e9422 ;;
  Linux-aarch64) platform=linux-arm64; sum=8bd3dc69eee8f3f226315a80d7d1d4faccf217a4c8fae500168ac2e38f3bdba3 ;;
  Linux-x86_64) platform=linux-x64; sum=c54118104acc524633b5abe106bbf44a53126ec8b4e5fa105cb92b5d7de8a1a1 ;;
  *) echo '请安装 Node.js 22 或更新版本，然后运行 node start.cjs'; exit 1 ;;
esac
archive="node-$version-$platform"
runtime="$HOME/.pingpong-checkout-h5/runtime"
if [ ! -x "$runtime/$archive/bin/node" ]; then
  umask 077
  mkdir -p "$runtime"
  temp=$(mktemp -d "$runtime/.install.XXXXXXXX")
  trap 'rm -rf "$temp"' EXIT
  echo "正在从 nodejs.org 下载并校验 Node.js $version"
  curl --fail --location --proto '=https' --proto-redir '=https' --retry 2 "https://nodejs.org/dist/$version/$archive.tar.gz" -o "$temp/runtime.tar.gz"
  if command -v shasum >/dev/null; then actual=$(LC_ALL=C shasum -a 256 "$temp/runtime.tar.gz"); else actual=$(sha256sum "$temp/runtime.tar.gz"); fi
  [ "${actual%% *}" = "$sum" ] || { echo 'Node.js 压缩包校验失败'; exit 1; }
  tar -xzf "$temp/runtime.tar.gz" -C "$temp"
  if [ ! -d "$runtime/$archive" ]; then mv "$temp/$archive" "$runtime/"; fi
  rm -rf "$temp"
  trap - EXIT
fi
exec "$runtime/$archive/bin/node" start.cjs
